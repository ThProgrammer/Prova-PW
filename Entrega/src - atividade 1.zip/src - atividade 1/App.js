//import logo from './logo.svg';
import './App.css';
import Imc from "./components/Imc"

function App() {
  return (
    <div>
      <Imc/>
    </div>
  );
}

export default App;
