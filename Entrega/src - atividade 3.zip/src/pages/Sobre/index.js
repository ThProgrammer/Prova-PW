import Header from "../../components/Header";
import './sobre.css'

function Sobre() {
    return (
        <>
            <Header></Header>
            <h1>Sobre nós</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Placerat in egestas erat imperdiet sed euismod nisi porta lorem. Tincidunt tortor aliquam nulla facilisi cras. Id neque aliquam vestibulum morbi blandit cursus risus at ultrices. Gravida rutrum quisque non tellus orci ac. Pellentesque eu tincidunt tortor aliquam nulla facilisi cras. Morbi tristique senectus et netus et. Dui vivamus arcu felis bibendum ut. Nulla pharetra diam sit amet nisl suscipit. At consectetur lorem donec massa sapien. Risus sed vulputate odio ut enim blandit. Odio aenean sed adipiscing diam donec adipiscing tristique risus. Eros donec ac odio tempor orci dapibus ultrices. Mi sit amet mauris commodo. Commodo odio aenean sed adipiscing diam. Proin sagittis nisl rhoncus mattis rhoncus urna. A iaculis at erat pellentesque adipiscing commodo elit at imperdiet. Pharetra vel turpis nunc eget. Diam phasellus vestibulum lorem sed.<br/><br/>

Purus viverra accumsan in nisl nisi scelerisque eu ultrices vitae. Nisl purus in mollis nunc sed. Mollis aliquam ut porttitor leo a. Volutpat maecenas volutpat blandit aliquam etiam erat. Tellus cras adipiscing enim eu turpis. Faucibus ornare suspendisse sed nisi lacus sed. Pellentesque habitant morbi tristique senectus et netus et. Nec tincidunt praesent semper feugiat nibh. Pellentesque nec nam aliquam sem et tortor consequat id. Pharetra pharetra massa massa ultricies mi quis hendrerit dolor magna. Turpis egestas integer eget aliquet nibh. Sem viverra aliquet eget sit. Maecenas pharetra convallis posuere morbi leo. Purus sit amet luctus venenatis lectus magna fringilla urna. Ac auctor augue mauris augue neque gravida. Vitae purus faucibus ornare suspendisse sed nisi lacus. Amet facilisis magna etiam tempor orci eu lobortis elementum. Nunc faucibus a pellentesque sit.</p>
        </>
        
    )
}

export default Sobre;