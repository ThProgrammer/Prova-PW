import Header from "../../components/Header";
import './home.css';

function Home() {
    return (
        <>
        <Header></Header>
        <h1>BEM VINDO!</h1>
        </>
    )
}

export default Home;